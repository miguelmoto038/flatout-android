# MANX FlatOut 1 - Android (esqueleto)

Roda os diagnósticos do MANXFlatOut1 (por padrão o `FlatOut1Boot`, visualizador SDL)
em Android 15 / arm64 (Adreno). **Ainda não é o jogo**: o código x86 não foi recompilado.

## 1. Estrutura de pastas
    workspace/
      MANXFramework/          git clone https://github.com/RetroRecompilations/MANXFramework
      MANXFlatOut1/           git clone https://github.com/RetroRecompilations/MANXFlatOut1
      MANXFlatOut1-Android/   este projeto

## 2. SDL3 (dentro deste projeto)
    cd MANXFlatOut1-Android
    git init
    git submodule add https://github.com/libsdl-org/SDL SDL
    cd SDL && git checkout release-3.2.x   # use a release estável mais recente

## 3. Build
Abra a pasta no Android Studio (SDK 35 + NDK 27 + CMake 3.22.1 instalados via SDK Manager)
e rode Build > Build APK (debug), ou instale direto no celular com depuração USB.

Para lançar o teste D3D8->Vulkan em vez do boot, troque `-DFLATOUT_ENTRY=Boot`
por `-DFLATOUT_ENTRY=D3DProbe` em `app/build.gradle.kts`.

## 4. Arquivos do jogo (os seus)
Copie o jogo extraído do Xbox para a pasta do app:

    adb push game_data /sdcard/Android/data/com.manx.flatout1/files/game_data

Rode o app uma vez antes, para o Android criar a pasta. Veja o log com:

    adb logcat -s SDL SDL/APP MANX

## Pontos de atenção
- Nunca testado: o esqueleto foi escrito sem poder compilar.
- O MANXFramework pode ter dependências ou código só de desktop (Vulkan loader, x86, paths).
  Os primeiros erros de build provavelmente virão de lá.
- Os executáveis do jogo não usam SDL_main; o CMake renomeia `main` para `flatout1_entry`.
