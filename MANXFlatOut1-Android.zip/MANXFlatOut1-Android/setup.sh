#!/usr/bin/env bash
# Clona as dependências, prepara o SDL3 e gera o APK de debug.
# Requisitos: git, JDK 17, Android SDK (ANDROID_HOME) com NDK 27 e CMake 3.22.1,
# e o comando `gradle` instalado (só para gerar o gradlew na primeira vez).
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
WS="$(dirname "$HERE")"

[ -n "${ANDROID_HOME:-}" ] || { echo "Defina ANDROID_HOME (pasta do Android SDK)."; exit 1; }

[ -d "$WS/MANXFramework" ] || git clone https://github.com/RetroRecompilations/MANXFramework "$WS/MANXFramework"
[ -d "$WS/MANXFlatOut1" ]  || git clone https://github.com/RetroRecompilations/MANXFlatOut1  "$WS/MANXFlatOut1"

cd "$HERE"
[ -f SDL/CMakeLists.txt ] || git clone --depth 1 --branch release-3.2.x https://github.com/libsdl-org/SDL SDL

echo "sdk.dir=$ANDROID_HOME" > local.properties

if [ ! -f gradlew ]; then
  command -v gradle >/dev/null || { echo "Instale o gradle ou abra o projeto no Android Studio."; exit 1; }
  gradle wrapper --gradle-version 8.9
fi

./gradlew assembleDebug
echo "APK: $HERE/app/build/outputs/apk/debug/app-debug.apk"
echo "Instalar: adb install -r app/build/outputs/apk/debug/app-debug.apk"
