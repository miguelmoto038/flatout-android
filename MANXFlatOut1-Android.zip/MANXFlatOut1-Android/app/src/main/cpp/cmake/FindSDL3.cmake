# SDL3 is built in-tree via add_subdirectory(), so the game's
# find_package(SDL3 REQUIRED) just has to confirm the target exists.
include(FindPackageHandleStandardArgs)
if(TARGET SDL3::SDL3)
    set(SDL3_FOUND TRUE)
else()
    set(SDL3_FOUND FALSE)
endif()
find_package_handle_standard_args(SDL3 REQUIRED_VARS SDL3_FOUND)
