/* Android glue: SDL3 calls SDL_main() in libmain.so.
 * We point the working directory at the app's external files dir so the game's
 * relative "game_data/" path works, then call the original main(), which the
 * build renames to flatout1_entry. */
#include <SDL3/SDL.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>

int flatout1_entry(int argc, char **argv);

__attribute__((visibility("default")))
int SDL_main(int argc, char *argv[])
{
    const char *base = SDL_GetAndroidExternalStoragePath();
    if (!base) {
        SDL_Log("MANX: external storage path unavailable");
        return 1;
    }

    char path[1024];
    snprintf(path, sizeof path, "%s/game_data", base);
    mkdir(path, 0775);

    if (chdir(base) != 0) {
        SDL_Log("MANX: chdir(%s) failed", base);
        return 1;
    }
    SDL_Log("MANX: working dir = %s (put game files in game_data/)", base);

    return flatout1_entry(argc, argv);
}
