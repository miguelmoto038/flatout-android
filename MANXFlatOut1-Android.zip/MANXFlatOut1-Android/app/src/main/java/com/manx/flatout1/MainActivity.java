package com.manx.flatout1;

import org.libsdl.app.SDLActivity;

/** SDL3 loads libSDL3.so and libmain.so and calls SDL_main (see android_entry.c). */
public class MainActivity extends SDLActivity {
}
