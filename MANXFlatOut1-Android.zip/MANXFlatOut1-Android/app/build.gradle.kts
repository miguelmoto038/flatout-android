plugins {
    id("com.android.application")
}

android {
    namespace = "com.manx.flatout1"
    compileSdk = 35
    ndkVersion = "27.0.12077973"

    defaultConfig {
        applicationId = "com.manx.flatout1"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"

        ndk { abiFilters += "arm64-v8a" }

        externalNativeBuild {
            cmake {
                // Only build the "main" library (SDL3 is built as its dependency).
                targets += "main"
                arguments += listOf(
                    "-DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON", // Android 15: 16 KB pages
                    "-DFLATOUT_ENTRY=Boot"                      // Boot | D3DProbe
                )
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    sourceSets {
        getByName("main") {
            // SDLActivity and friends come straight from the SDL3 submodule.
            java.srcDir("../SDL/android-project/app/src/main/java")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
